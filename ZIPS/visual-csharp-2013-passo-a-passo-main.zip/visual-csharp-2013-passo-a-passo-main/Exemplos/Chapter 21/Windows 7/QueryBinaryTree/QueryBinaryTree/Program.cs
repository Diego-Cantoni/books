﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryBinaryTree
{
    class Program
    {
        static void doWork()
        {
            // TODO:
        }

        static void Main()
        {
            try
            {
                doWork();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: {0}", ex.Message);
            }
        }
    }
}
